#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int x,y,a,b,res;
  printf("Bienvenido a este programa para resolver la expresion (x+y)^2(a-b)\n");
  printf("A continuacion ingresa el valor de x\n");
  scanf("%d",&x);
  printf("A continuacion ingresa el valor de y\n");
  scanf("%d",&y);
  printf("A continuacion ingresa el valor de a\n");
  scanf("%d",&a);
  printf("A continuacion ingresa el valor de b\n");
  scanf("%d",&b);
  res=(x+y)*(x+y)*(a-b);
  printf("A continuacion se muestra el resultado\n");
  printf("El resultado es %d\n",res);
  system("PAUSE");	
  return 0;
}
