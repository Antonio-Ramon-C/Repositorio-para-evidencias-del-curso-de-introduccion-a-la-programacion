#include <stdio.h>
#include <stdlib.h>
#define max(a,b) (a>=b)? a:b

int absoluto (int X)
    {
     return (X>0)? X:-X;
    }
         

int main(int argc, char *argv[])
{
  int A=-10,B=725, R;
  A=absoluto(A);
  B=absoluto(B);
  printf("%d\t%d\n",A,B);
  R=A;
  A=max(A,B);
  B=(A-R!=0)?R:B;
  printf("%d\t%d\n",A,B);
  inicio:
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         //__asm("mov $0X0 %eaX"); Codigo de ensamblador en l\'inea
  //       goto inicio;
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         R=A%B;
         A=B;
         B=(R==0)?B:R;
         printf("R=%d\tB=%d\n",R,B);
         B=(R==0)?B:R;
         A=-1;
         int I;
         for(I=31; I>=0;  I--)
                 {
                  B=A>>I;
                  printf("%d",B&1);
                 }
                 
  system("PAUSE");	
  return 0;
}
